package com.thud.dulichdalat.ui.dangky;

import androidx.lifecycle.ViewModel;

public class DangKyViewModel extends ViewModel {
    // TODO: Implement the ViewModel
}
package com.thud.dulichdalat.ui.hinhanh;

import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.ViewModel;

public class HinhAnhViewModel extends ViewModel {

}